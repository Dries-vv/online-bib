<?php 
    include "./dbh.php";
    $response = array();


    $BoekNaam = $_POST['BoekNaam'];
    $flaptext = $_POST['flaptext'];
    $id = generateUUIDv4();
    $sql = "INSERT INTO `boeken`(`BoekNaam`, `flaptext`,`id`) VALUES (?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sss', $BoekNaam,$flaptext,$id);
    $statement->execute();


    echo json_encode($response);
?> 