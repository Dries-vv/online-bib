<?php
$response = array();
$html = '';
include './dbh.php';

$filterValue = $_POST['filterValue'];
$sql = "SELECT * FROM boeken";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {

    if (str_contains(strtolower($row['BoekNaam']), strtolower($filterValue))) {
        $html .= '<div class="row g-0 align-items-center">';
        $html .= '<div class="col-md-3 text-center">';
        $html .= '<img src="' . htmlspecialchars($row['img']) . '" class="img-fluid rounded" alt="' . htmlspecialchars($row['BoekNaam']) . '" style="max-width: 150px;">';
        $html .= '</div>';
        $html .= '<div class="col-md-6">';
        $html .= '<div class="card-body">';
        $html .= '<h5 class="card-title">' . htmlspecialchars($row['BoekNaam']) . '</h5>';
        $html .= '<p class="card-text">' . htmlspecialchars(mb_strimwidth($row['flaptext'], 0, 150 , '...')) . '</p>';
        $html .= '</div></div>';
        $html .= '<div class="col-md-3 text-center">';
        $html .= '<a class="btn btn-primary" href="./boek.php?id='.$row['id'].'" target="_blank" >Meer info</a>';
        $html .= '</div></div>';
        $html .= '<hr>';  
    }  

}
$response['html'] = $html;
echo json_encode($response);
?>