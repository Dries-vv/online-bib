<?php
include './dbh.php'; 
$id = $_POST['id']; 
$response = array();

$sql = "UPDATE `boeken` SET `status` = 'uitgeleend' WHERE id = ?";
$statement = $conn->prepare($sql);
$statement->bind_param('s', $id);
$statement->execute();

echo json_encode($response);
?>
