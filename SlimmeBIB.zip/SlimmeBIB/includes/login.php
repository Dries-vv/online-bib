<?php
include "./dbh.php";
session_start();
$message = array('');

$email = $_POST['email'];
$password = $_POST['password'];

if (empty($email) || empty($password)) {
  $message[0] = 'no';
  $message[1] = 'Niet alle velden ingevuld';
} else {
  $sql = "SELECT * FROM users WHERE email='$email'";
  $result = mysqli_query($conn, $sql);
  $resultCheck = mysqli_num_rows($result);
  if ($resultCheck < 1){
    $message[0] = 'no';
    $message[1] = 'Geen gebruiker gevonden';
  } else {
    if ($row = mysqli_fetch_assoc($result)) {
      if ($password != $row['password']) {
        $message[0] = 'no';
        $message[1] = 'Wachtwoord incorrect';
      } elseif ($password == $row['password']) {
        $_SESSION['user'] = $email;
        $_SESSION['admin'] = $row['admin'];
        $message[0] = 'yes';
        $message[1] = $email;
      }
    }
  }
}
echo json_encode($message);
