<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="./js/boeken.js"> </script>
    <link rel="stylesheet" href="./style/huur.css">

    <meta charset="UTF-8">
    <title>Kies huurperiode | Bibliotheek</title>
</head>

<body>

    <header>
        <h1>Bibliotheek Portaal</h1>
    </header>

    <div class="container">
        <h2>📅 Kies een huurperiode voor je boek</h2>
        <div>
            <label for="begin_datum">Begindatum:</label>
            <input type="date" id="begin_datum" name="begin_datum" required>

            <label for="eind_datum">Einddatum:</label>
            <input type="date" id="eind_datum" name="eind_datum" required>

            <button onclick="huurBoek('<?php echo $_GET['id'] ?>')">Bevestig periode</button>
        </div>
        <div id="message"></div>
    </div>

</body>

</html>