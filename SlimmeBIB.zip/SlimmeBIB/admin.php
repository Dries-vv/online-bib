<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
  include './header.php';
  ?>
  <div class="container" id="adminPage">
    <h1>Welcome <?php echo $_SESSION['user'] ?></h1>
</body>
</html>