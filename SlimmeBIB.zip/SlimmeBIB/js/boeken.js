function insertBoek() {
    const BoekNaam = $('#BoekNaam').val();
    const flaptext = $('#flaptext').val();
    if (!BoekNaam || !flaptext) {
        $('#errorMessage').css({ 'display': 'block' })
        $('#errorMessage').html('Niet alle velden zijn ingevuld')
    }
    else {
        $.ajax({
            url: './includes/boek-insert.php',
            method: 'POST',
            data: {
                BoekNaam,
                flaptext
            },
            datatype: 'json',
            success: function () {
                console.log('yeah');
                $('#succesMessageBoek').css({ 'display': 'block' })
                $('#succesMessageBoek').html('Boek toegevoegd')
                setTimeout(function () {
                    location.reload();
                }, 3000);
            }

        }
        )
    }
}
$(document).ready(function () {
    getBoeken()
});

function getBoeken() {
    const filterValue = $('#filterValue').val();
    $.ajax({
        url: './includes/boeken-get.php',
        data: {
            filterValue
        },
        method: 'POST',
        dataType: 'JSON',
        success: function (data) {
            console.log(data)
            $("#boekenfield").html(data['html'])
        }


    });

}

function checkLogin(bookId) {
    if (isLoggedIn == true) {
        window.location.href = "./huur.php";
    } else {
        window.location.href = "./login.php"
    }

}

function huurBoek(id) {
    console.log('okokok');
    
    const eind_datum = $('#eind_datum').val();
    const begin_datum = $('#begin_datum').val();

    if (!eind_datum || !begin_datum) {
        $('#message').html('Niet alle velden zijn ingevuld')
    } else if (eind_datum < begin_datum) {
        $('#message').html('De eindtijd ligt voor de begintijd!!')
    } else {
        $.ajax({
            url: './includes/status.php',
            method: 'POST',
            data: {
                id
            },
            dataType: 'json',
            success: function (response) {
                $('#message').css({ 'display': 'block' })
                $('#message').html('Succesvol gehuurd van ' + begin_datum + ' tot ' + eind_datum);
                setTimeout(function () {
                    location.reload();
                    window.location.href = "./boeken.php";
                }, 3000);

            }

        })
    }
}

