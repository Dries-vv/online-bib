function login() {
    const email = $('#email').val();
    const password = $('#password').val();

    $.ajax({
        url: "./includes/login.php",
        method: "POST",
        data: {
            email,
            password
        },
        dataType: "json",
        success: function(data) {
            if (data[0] == 'yes') {
              $('.alert').html('Je bent aangemeld');
              $('.alert').css({
                'background-color': '#69be6c',
                'padding': '20px'
              });
              $('.alert').slideDown("Slow");
              setTimeout(function() {
                $('.alert').slideUp("Slow");
                $('.alert').css({
                  'padding': '0px'
                });
              }, 2000);
              setTimeout(function() {
                window.location.href = "./admin.php";
              }, 3000);
            } else {
              $('.alert').html(data[1]);
              $('.alert').css({
                'background-color': '#dd625d',
                'padding': '20px'
              });
              $('.alert').slideDown("Slow");
              setTimeout(function() {
                $('.alert').slideUp("Slow");
                $('.alert').css({
                  'padding': '0px'
                });
              }, 2000);
            }
          }

    }
    )

}