<?php
session_start();
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Povil BIB - Welkom</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
    <?php include './header.php'; ?>

    <div class="hero-section">
        <div class="welcome-box">
            <h1>Welkom bij de Povil Bibliotheek</h1>
            <p>Duik in een wereld vol verhalen, kennis en inspiratie.<br>Log in om toegang te krijgen tot al onze functies.</p>
            <a href="boeken.php" class="btn">Ontdek onze boeken</a>
        </div>
    </div>

</body>

<style>
    body {
        margin: 0;
        font-family: 'Roboto', sans-serif;
        background: linear-gradient(to right, #e0f7fa, #ffffff);
    }

    .hero-section {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 90vh;
        padding: 20px;
    }

    .welcome-box {
        background-color: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        text-align: center;
        max-width: 600px;
        width: 100%;
    }

    .welcome-box h1 {
        color: #00695c;
        font-size: 2.5em;
        margin-bottom: 20px;
    }

    .welcome-box p {
        font-size: 1.2em;
        color: #333;
        margin-bottom: 30px;
    }

    .btn {
        display: inline-block;
        padding: 12px 25px;
        font-size: 1em;
        color: white;
        background-color: #00897b;
        border: none;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }

    .btn:hover {
        background-color: #00695c;
    }
</style>

</html>
