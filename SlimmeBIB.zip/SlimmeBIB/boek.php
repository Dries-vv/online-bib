<?php
include './includes/dbh.php';
session_start();

$bookId = $_GET['id'];

$sql = "SELECT id, BoekNaam, flaptext, img, auteur, doelgroep, genre , status FROM boeken WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $bookId);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $book['BoekNaam']; ?> | Bibliotheek</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="./js/boeken.js"></script>
    <style>
        body {
            background-color: #f8f6f1;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
        }

        .navbar {
            background-color: #1e2331;
            ;
        }

        .navbar-brand {
            color: #ecf0f1 !important;
        }

        .book-card {
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h1 {
            color: #2c3e50;
            font-weight: 600;
        }

        .btn-danger {
            background-color: #c0392b;
            border: none;
        }

        .btn-danger:hover {
            background-color: #e74c3c;
        }

        .btn-primary {
            background-color: #2980b9;
            border: none;
        }

        .btn-primary:hover {
            background-color: #3498db;
        }

        .nav-tabs .nav-link.active {
            background-color: #2980b9;
            color: white;
        }

        .nav-tabs .nav-link {
            color: #2980b9;
        }

        .book-image {
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
            max-width: 20rem;
            max-height: 20rem;
        }

        .meta-text strong {
            color: #34495e;
        }

        .footer-link {
            margin-top: 40px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="./boeken.php">📚 Mijn Bibliotheek</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="book-card">
            <div class="row g-4">
                <div class="col-md-4 text-center">
                    <img src="<?php echo $book['img']; ?>" class="img-fluid book-image" alt="<?php echo $book['BoekNaam']; ?>">
                </div>
                <div class="col-md-8">
                    <h1><?php echo $book['BoekNaam']; ?></h1>
                    <p class="meta-text"><strong>Auteur:</strong> <?php echo $book['auteur']; ?></p>
                    <p class="meta-text"><strong>Doelgroep:</strong> <?php echo $book['doelgroep']; ?></p>
                    <p class="meta-text"><strong>Genre:</strong> <?php echo $book['genre']; ?></p>
                    <p class="meta-text"><strong>Status:</strong> <?php echo $book['status']; ?></p>
                    <a class="btn btn-danger mt-3" href="huur.php?id=<?php echo $bookId; ?>">
                        <i class="bi bi-book"></i> Huur dit boek
                    </a>

                </div>
            </div>

            <div class="mt-4">
                <ul class="nav nav-tabs" id="bookTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="inhoud-tab" data-bs-toggle="tab" data-bs-target="#inhoud" type="button" role="tab">Inhoud</button>
                    </li>
                </ul>
                <div class="tab-content mt-2" id="bookTabsContent">
                    <div class="tab-pane fade show active" id="inhoud" role="tabpanel">
                        <p><?php echo $book['flaptext']; ?></p>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-center footer-link">
                <a href="./boeken.php" class="btn btn-primary">← Terug naar overzicht</a>
            </div>
        </div>
    </div>

    <script>
        var isLoggedIn = <?php echo (isset($_SESSION['user'])) ? 'true' : 'false'; ?>;
    </script>
</body>

</html>