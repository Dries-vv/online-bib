<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <title>Cross der jongeren</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="./js/boekInsert.js"> </script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            border-radius: 8px;
        }

        .alert {
            border-radius: 8px;
        }

        .container {
            margin-top: 50px;
        }

        .card-header {
            background-color: #f1f1f1;
            border-radius: 10px;
            padding: 10px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <?php include './header.php'; ?>

    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="card mt-5">
                    <h4 class="mb-4 text-primary text-center">Voeg boek toe</h4>
                    <div class="form-group">
                        <label for="schoolName" class="form-label">Boek</label>
                        <input type="text" id="BoekNaam" name="BoekNaam" class="form-control" placeholder="Voer de schoolnaam in" required>
                        <label for="flaptext" class="form-label">Korte inhoud</label>
                        <input type="text" id="flaptext" name="flaptext" class="form-control" placeholder="Geef de flaptext" required>
                    </div>
                    <div class="col-12 mt-3">
                        <div id="succesMessageBoek" class="alert alert-success mt-3 text-center" style="display: none;">
                            Boek succesvol toegevoegd!
                        </div>
                        <div id="errorMessage" class="alert alert-danger mt-3 text-center" style="display: none;">
                            Niet alle velden ingevuld!
                        </div>
                        <button type="submit" onclick="insertBoek()" class="btn btn-primary w-100">Voeg boek toe!</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>