<?php
session_start();
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boeken Overzicht</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <?php include 'header.php' ?>
    <div class="d-flex justify-content-center" style="margin-top: 5vh;">
        <input type="text" class="form-control" onchange="getBoeken()" style="width:32rem;" id="filterValue">
    </div>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card mb-4 w-75 p-3 shadow-lg">
            <div id="boekenfield"></div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="boekModal" tabindex="-1" aria-labelledby="boekModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="boekModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <img id="boekModalImg" src="" class="img-fluid mb-3" alt="">
                    <p id="boekModalBody"></p>
                </div>
                <div class="modal-footer">
                    <a id="downloadLink" href="#" class="btn btn-success" download>Download Boekpagina</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<script src="./js/boeken.js"></script>
